import React, { useContext, useState } from "react";
import { UserContext } from "../context/UserContext";
import EditModal from "./EditModal";

const UserCard = () => {
  const { users, deleteUser, toggleLike } = useContext(UserContext);
  const [editingUser, setEditingUser] = useState(null);

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this user?")) {
      deleteUser(id);
    }
  };

  return (
    <>
      {users.map((user) => (
        <div key={user.id} className="user-card">
          <div className="avatar-container">
            <img
              src={`https://avatars.dicebear.com/v2/avataaars/${user.username}.svg?options[mood][]=happy`}
              alt={`${user.name}'s avatar`}
              className="avatar"
            />
          </div>
          <div className="user-info">
            <h2>{user.name}</h2>
            <p>
              <strong>Email:</strong> {user.email}
            </p>
            <p>
              <strong>Phone:</strong> {user.phone}
            </p>
            <p>
              <strong>Address:</strong> {user.address.street},{" "}
              {user.address.suite}, {user.address.city}, {user.address.zipcode}
            </p>
            <p>
              <strong>Website:</strong>{" "}
              <a
                href={`http://${user.website}`}
                target="_blank"
                rel="noopener noreferrer"
              >
                {user.website}
              </a>
            </p>
            <p>
              <strong>Company:</strong> {user.company.name}
            </p>
          </div>
          <div className="action-buttons">
            <button
              className={`like-btn ${user.liked ? "liked" : ""}`}
              onClick={() => toggleLike(user.id)}
            >
              {user.liked ? "❤️ Liked" : "🤍 Like"}
            </button>
            <button className="edit-btn" onClick={() => setEditingUser(user)}>
              ✏️ Edit
            </button>
            <button
              className="delete-btn"
              onClick={() => handleDelete(user.id)}
            >
              🗑️ Delete
            </button>
          </div>
        </div>
      ))}
      {editingUser && (
        <EditModal user={editingUser} onClose={() => setEditingUser(null)} />
      )}
    </>
  );
};

export default UserCard;
