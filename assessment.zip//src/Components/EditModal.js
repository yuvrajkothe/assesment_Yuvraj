import React, { useState, useContext } from "react";
import { UserContext } from "../context/UserContext";

const EditModal = ({ user, onClose }) => {
  const { updateUser } = useContext(UserContext);
  const [editedUser, setEditedUser] = useState({ ...user });

  const handleChange = (e) => {
    const { name, value } = e.target;
    if (name.includes("address.")) {
      const field = name.split(".")[1];
      setEditedUser({
        ...editedUser,
        address: {
          ...editedUser.address,
          [field]: value,
        },
      });
    } else if (name.includes("company.")) {
      const field = name.split(".")[1];
      setEditedUser({
        ...editedUser,
        company: {
          ...editedUser.company,
          [field]: value,
        },
      });
    } else {
      setEditedUser({
        ...editedUser,
        [name]: value,
      });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    updateUser(editedUser);
    onClose();
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <h2>Edit User</h2>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Name:</label>
            <input
              type="text"
              name="name"
              value={editedUser.name}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Username:</label>
            <input
              type="text"
              name="username"
              value={editedUser.username}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Email:</label>
            <input
              type="email"
              name="email"
              value={editedUser.email}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Phone:</label>
            <input
              type="text"
              name="phone"
              value={editedUser.phone}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Website:</label>
            <input
              type="text"
              name="website"
              value={editedUser.website}
              onChange={handleChange}
            />
          </div>
          <h3>Address</h3>
          <div className="form-group">
            <label>Street:</label>
            <input
              type="text"
              name="address.street"
              value={editedUser.address.street}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Suite:</label>
            <input
              type="text"
              name="address.suite"
              value={editedUser.address.suite}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>City:</label>
            <input
              type="text"
              name="address.city"
              value={editedUser.address.city}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Zipcode:</label>
            <input
              type="text"
              name="address.zipcode"
              value={editedUser.address.zipcode}
              onChange={handleChange}
            />
          </div>
          <h3>Company</h3>
          <div className="form-group">
            <label>Name:</label>
            <input
              type="text"
              name="company.name"
              value={editedUser.company.name}
              onChange={handleChange}
            />
          </div>
          <div className="modal-buttons">
            <button type="button" onClick={onClose}>
              Cancel
            </button>
            <button type="submit">Save</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditModal;
