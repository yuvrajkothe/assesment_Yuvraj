import React, { useState, useEffect } from "react";
import UserCard from "./components/UserCard";
import LoadingSpinner from "./components/LoadingSpinner";
import { UserProvider } from "./context/UserContext";
import "./styles.css";

function App() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate API loading
    setTimeout(() => {
      setLoading(false);
    }, 1500);
  }, []);

  return (
    <UserProvider>
      <div className="app">
        <header className="header">
          <h1>User Profiles</h1>
        </header>
        <main className="main-content">
          {loading ? (
            <LoadingSpinner />
          ) : (
            <div className="users-container">
              <UserCard />
            </div>
          )}
        </main>
      </div>
    </UserProvider>
  );
}

export default App;
