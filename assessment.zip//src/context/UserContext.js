import React, { createContext, useState, useEffect } from "react";

export const UserContext = createContext();

export const UserProvider = ({ children }) => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    // Fetch data from API
    const fetchUsers = async () => {
      try {
        const response = await fetch(
          "https://jsonplaceholder.typicode.com/users"
        );
        const data = await response.json();
        // Only take first 10 users and add liked property
        const usersWithLikes = data.slice(0, 10).map((user) => ({
          ...user,
          liked: false,
        }));
        setUsers(usersWithLikes);
      } catch (error) {
        console.error("Error fetching users:", error);
        // Fallback data if API fails
        setUsers([
          {
            id: 1,
            name: "Leanne Graham",
            username: "Bret",
            email: "Sincere@april.biz",
            phone: "1-770-736-8031 x56442",
            website: "hildegard.org",
            address: {
              street: "Kulas Light",
              suite: "Apt. 556",
              city: "Gwenborough",
              zipcode: "92998-3874",
            },
            company: {
              name: "Romaguera-Crona",
            },
            liked: false,
          },
          // ... more fallback users if needed
        ]);
      }
    };

    fetchUsers();
  }, []);

  const toggleLike = (id) => {
    setUsers(
      users.map((user) =>
        user.id === id ? { ...user, liked: !user.liked } : user
      )
    );
  };

  const updateUser = (updatedUser) => {
    setUsers(
      users.map((user) => (user.id === updatedUser.id ? updatedUser : user))
    );
  };

  const deleteUser = (id) => {
    setUsers(users.filter((user) => user.id !== id));
  };

  return (
    <UserContext.Provider value={{ users, toggleLike, updateUser, deleteUser }}>
      {children}
    </UserContext.Provider>
  );
};
